# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Data_Setup.ui'
##
## Created by: Qt User Interface Compiler version 6.6.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QLabel, QMainWindow,
    QMenuBar, QPushButton, QSizePolicy, QStatusBar,
    QTextEdit, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(745, 478)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.label = QLabel(self.centralwidget)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(30, 50, 53, 32))
        font = QFont()
        font.setFamilies([u"Arial"])
        font.setPointSize(20)
        self.label.setFont(font)
        self.label_2 = QLabel(self.centralwidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(30, 127, 144, 32))
        self.label_2.setFont(font)
        self.label_3 = QLabel(self.centralwidget)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(30, 210, 95, 32))
        self.label_3.setFont(font)
        self.label_4 = QLabel(self.centralwidget)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(30, 287, 203, 32))
        self.label_4.setFont(font)
        self.Text_Type = QTextEdit(self.centralwidget)
        self.Text_Type.setObjectName(u"Text_Type")
        self.Text_Type.setGeometry(QRect(90, 50, 201, 31))
        font1 = QFont()
        font1.setPointSize(12)
        self.Text_Type.setFont(font1)
        self.Text_Type.setStyleSheet(u"")
        self.Text_State = QTextEdit(self.centralwidget)
        self.Text_State.setObjectName(u"Text_State")
        self.Text_State.setGeometry(QRect(180, 130, 161, 31))
        self.Text_State.setFont(font1)
        self.Text_State.setStyleSheet(u"")
        self.PB_Add_Type = QPushButton(self.centralwidget)
        self.PB_Add_Type.setObjectName(u"PB_Add_Type")
        self.PB_Add_Type.setGeometry(QRect(530, 50, 91, 31))
        self.PB_Dell_Type = QPushButton(self.centralwidget)
        self.PB_Dell_Type.setObjectName(u"PB_Dell_Type")
        self.PB_Dell_Type.setGeometry(QRect(640, 50, 91, 31))
        self.Text_Project = QTextEdit(self.centralwidget)
        self.Text_Project.setObjectName(u"Text_Project")
        self.Text_Project.setGeometry(QRect(140, 210, 201, 31))
        self.Text_Project.setFont(font1)
        self.Text_Project.setStyleSheet(u"")
        self.Text_Subdive = QTextEdit(self.centralwidget)
        self.Text_Subdive.setObjectName(u"Text_Subdive")
        self.Text_Subdive.setGeometry(QRect(240, 290, 151, 31))
        self.Text_Subdive.setFont(font1)
        self.Text_Subdive.setStyleSheet(u"")
        self.PB_Add_State = QPushButton(self.centralwidget)
        self.PB_Add_State.setObjectName(u"PB_Add_State")
        self.PB_Add_State.setGeometry(QRect(530, 130, 91, 31))
        self.PB_Dell_State = QPushButton(self.centralwidget)
        self.PB_Dell_State.setObjectName(u"PB_Dell_State")
        self.PB_Dell_State.setGeometry(QRect(640, 130, 91, 31))
        self.PB_Dell_Project = QPushButton(self.centralwidget)
        self.PB_Dell_Project.setObjectName(u"PB_Dell_Project")
        self.PB_Dell_Project.setGeometry(QRect(640, 210, 91, 31))
        self.PB_Add_Project = QPushButton(self.centralwidget)
        self.PB_Add_Project.setObjectName(u"PB_Add_Project")
        self.PB_Add_Project.setGeometry(QRect(530, 210, 91, 31))
        self.PB_Add_Sabdvide = QPushButton(self.centralwidget)
        self.PB_Add_Sabdvide.setObjectName(u"PB_Add_Sabdvide")
        self.PB_Add_Sabdvide.setGeometry(QRect(530, 290, 91, 31))
        self.PB_Dell_Sabdvide = QPushButton(self.centralwidget)
        self.PB_Dell_Sabdvide.setObjectName(u"PB_Dell_Sabdvide")
        self.PB_Dell_Sabdvide.setGeometry(QRect(640, 290, 91, 31))
        self.Box_Type = QComboBox(self.centralwidget)
        self.Box_Type.setObjectName(u"Box_Type")
        self.Box_Type.setGeometry(QRect(290, 50, 231, 31))
        self.Box_Type.setStyleSheet(u"border: 1px solid gray;")
        self.Box_State = QComboBox(self.centralwidget)
        self.Box_State.setObjectName(u"Box_State")
        self.Box_State.setGeometry(QRect(340, 130, 181, 31))
        self.Box_State.setStyleSheet(u"border: 1px solid gray;")
        self.Box_Project = QComboBox(self.centralwidget)
        self.Box_Project.setObjectName(u"Box_Project")
        self.Box_Project.setGeometry(QRect(340, 210, 181, 31))
        self.Box_Project.setStyleSheet(u"border: 1px solid gray;")
        self.Box_Subdive = QComboBox(self.centralwidget)
        self.Box_Subdive.setObjectName(u"Box_Subdive")
        self.Box_Subdive.setGeometry(QRect(390, 290, 131, 31))
        self.Box_Subdive.setStyleSheet(u"border: 1px solid gray;")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 745, 21))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Database_Setup", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"\u0422\u0438\u043f:", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"\u0421\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435:", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"\u041f\u0440\u043e\u0435\u043a\u0442:", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"\u041f\u043e\u0434\u0440\u0430\u0437\u0434\u0435\u043b\u0435\u043d\u0438\u0435:", None))
        self.PB_Add_Type.setText(QCoreApplication.translate("MainWindow", u"\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c", None))
        self.PB_Dell_Type.setText(QCoreApplication.translate("MainWindow", u"\u0423\u0434\u0430\u043b\u0438\u0442\u044c", None))
        self.PB_Add_State.setText(QCoreApplication.translate("MainWindow", u"\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c", None))
        self.PB_Dell_State.setText(QCoreApplication.translate("MainWindow", u"\u0423\u0434\u0430\u043b\u0438\u0442\u044c", None))
        self.PB_Dell_Project.setText(QCoreApplication.translate("MainWindow", u"\u0423\u0434\u0430\u043b\u0438\u0442\u044c", None))
        self.PB_Add_Project.setText(QCoreApplication.translate("MainWindow", u"\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c", None))
        self.PB_Add_Sabdvide.setText(QCoreApplication.translate("MainWindow", u"\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c", None))
        self.PB_Dell_Sabdvide.setText(QCoreApplication.translate("MainWindow", u"\u0423\u0434\u0430\u043b\u0438\u0442\u044c", None))
    # retranslateUi

