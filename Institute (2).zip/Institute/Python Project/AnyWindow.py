import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget
from MainIterface import Ui_MainWindow
from main import MainWindow
from QrGenerator import QR_
from Data_Setup import DSS
import sqlite3

con = sqlite3.connect("DataBace.db")
cur = con.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS Detail (
    ID_Detail   INTEGER PRIMARY KEY,
    Type        TEXT,
    Detail_Name TEXT,
    State       TEXT,
    Note        TEXT,
    ProjectNames TEXT,
    Sabdive     TEXT,
    Person_FIO  TEXT,
    Data        TEXT
    );""")

cur.execute("""CREATE TABLE IF NOT EXISTS Type (
    ID_Type   INTEGER PRIMARY KEY AUTOINCREMENT,
    Type_Name TEXT
);""")

cur.execute("""CREATE TABLE IF NOT EXISTS State (
    ID_State   INTEGER PRIMARY KEY AUTOINCREMENT,
    State_Name TEXT
);
""")

cur.execute("""CREATE TABLE IF NOT EXISTS Project (
    ID_Project   INTEGER PRIMARY KEY AUTOINCREMENT,
    Project_Name TEXT
);
""")

cur.execute("""CREATE TABLE IF NOT EXISTS Subdivision (
    ID_Subdivision   INTEGER PRIMARY KEY AUTOINCREMENT,
        Subdivision_Name TEXT
);
""")


class Interface(QMainWindow):
    def __init__(self, parent=None):
        super(Interface, self).__init__(parent)
        self.ui_Interface = Ui_MainWindow()
        self.ui_Interface.setupUi(self)

        self.ui_Interface.PB_Add_Element.clicked.connect(self.add_window)
        self.ui_Interface.PB_QR.clicked.connect(self.qr_generator_tb)
        self.ui_Interface.PB_Info.clicked.connect(self.Data_Setup_Setings)

    def add_window(self):
        self.w = MainWindow()
        self.w.show()

    def qr_generator_tb(self):
        self.q = QR_()
        self.q.show()

    def Data_Setup_Setings(self):
        self.DSS_Window = DSS()
        self.DSS_Window.show()




if __name__ == '__main__':
    app = QApplication()
    window = Interface()
    window.show()
    sys.exit(app.exec())





