# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_mainwindow.ui'
##
## Created by: Qt User Interface Compiler version 6.6.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QDateEdit, QLabel,
    QMainWindow, QMenuBar, QPushButton, QSizePolicy,
    QStatusBar, QTextEdit, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(766, 749)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.Labe_Status = QLabel(self.centralwidget)
        self.Labe_Status.setObjectName(u"Labe_Status")
        self.Labe_Status.setGeometry(QRect(110, 290, 101, 23))
        font = QFont()
        font.setPointSize(14)
        self.Labe_Status.setFont(font)
        self.Box_Status = QComboBox(self.centralwidget)
        self.Box_Status.addItem("")
        self.Box_Status.addItem("")
        self.Box_Status.addItem("")
        self.Box_Status.addItem("")
        self.Box_Status.setObjectName(u"Box_Status")
        self.Box_Status.setGeometry(QRect(220, 290, 371, 31))
        self.Box_Status.setStyleSheet(u"border: 1px solid gray;\n"
"border-radius:6px;")
        self.Labe_Name_ = QLabel(self.centralwidget)
        self.Labe_Name_.setObjectName(u"Labe_Name_")
        self.Labe_Name_.setGeometry(QRect(110, 190, 141, 23))
        self.Labe_Name_.setFont(font)
        self.Lable_Note_2 = QLabel(self.centralwidget)
        self.Lable_Note_2.setObjectName(u"Lable_Note_2")
        self.Lable_Note_2.setGeometry(QRect(110, 530, 116, 23))
        self.Lable_Note_2.setFont(font)
        self.Box_Project_Name = QComboBox(self.centralwidget)
        self.Box_Project_Name.addItem("")
        self.Box_Project_Name.addItem("")
        self.Box_Project_Name.addItem("")
        self.Box_Project_Name.setObjectName(u"Box_Project_Name")
        self.Box_Project_Name.setGeometry(QRect(190, 340, 401, 31))
        self.Box_Project_Name.setStyleSheet(u"border: 1px solid gray;\n"
"border-radius:6px;")
        self.Text_FIO_2 = QTextEdit(self.centralwidget)
        self.Text_FIO_2.setObjectName(u"Text_FIO_2")
        self.Text_FIO_2.setGeometry(QRect(180, 450, 411, 31))
        font1 = QFont()
        font1.setPointSize(12)
        self.Text_FIO_2.setFont(font1)
        self.Text_FIO_2.setStyleSheet(u"border: 1px solid gray;\n"
"border-radius: 5px;")
        self.Box_Name_Subdivade = QComboBox(self.centralwidget)
        self.Box_Name_Subdivade.addItem("")
        self.Box_Name_Subdivade.setObjectName(u"Box_Name_Subdivade")
        self.Box_Name_Subdivade.setGeometry(QRect(260, 400, 331, 31))
        self.Box_Name_Subdivade.setStyleSheet(u"border: 1px solid gray;\n"
"border-radius:6px;")
        self.Lable_FIO_2 = QLabel(self.centralwidget)
        self.Lable_FIO_2.setObjectName(u"Lable_FIO_2")
        self.Lable_FIO_2.setGeometry(QRect(110, 450, 59, 23))
        self.Lable_FIO_2.setFont(font)
        self.Labe_Count = QLabel(self.centralwidget)
        self.Labe_Count.setObjectName(u"Labe_Count")
        self.Labe_Count.setGeometry(QRect(110, 240, 111, 23))
        self.Labe_Count.setFont(font)
        self.Labe_Name_Project = QLabel(self.centralwidget)
        self.Labe_Name_Project.setObjectName(u"Labe_Name_Project")
        self.Labe_Name_Project.setGeometry(QRect(110, 340, 71, 23))
        self.Labe_Name_Project.setFont(font)
        self.Labe_Name_Subdivade = QLabel(self.centralwidget)
        self.Labe_Name_Subdivade.setObjectName(u"Labe_Name_Subdivade")
        self.Labe_Name_Subdivade.setGeometry(QRect(110, 400, 151, 23))
        self.Labe_Name_Subdivade.setFont(font)
        self.Box_Type = QComboBox(self.centralwidget)
        self.Box_Type.addItem("")
        self.Box_Type.addItem("")
        self.Box_Type.addItem("")
        self.Box_Type.setObjectName(u"Box_Type")
        self.Box_Type.setGeometry(QRect(160, 140, 431, 31))
        self.Box_Type.setStyleSheet(u"border: 1px solid gray;\n"
"border-radius:6px;")
        self.Labe_Type = QLabel(self.centralwidget)
        self.Labe_Type.setObjectName(u"Labe_Type")
        self.Labe_Type.setGeometry(QRect(110, 140, 41, 23))
        self.Labe_Type.setFont(font)
        self.Text_Note_2 = QTextEdit(self.centralwidget)
        self.Text_Note_2.setObjectName(u"Text_Note_2")
        self.Text_Note_2.setGeometry(QRect(110, 560, 481, 61))
        self.Text_Note_2.setFont(font1)
        self.Text_Note_2.setStyleSheet(u"border: 2px solid gray;\n"
"border-radius:10px;\n"
"")
        self.Text_Count = QTextEdit(self.centralwidget)
        self.Text_Count.setObjectName(u"Text_Count")
        self.Text_Count.setGeometry(QRect(230, 240, 361, 31))
        self.Text_Count.setFont(font1)
        self.Text_Count.setAcceptDrops(True)
        self.Text_Count.setAutoFillBackground(True)
        self.Text_Count.setStyleSheet(u"border: 1px solid gray;\n"
"border-radius: 5px;")
        self.Label_Bace_Title_ADD_ELEMENT = QLabel(self.centralwidget)
        self.Label_Bace_Title_ADD_ELEMENT.setObjectName(u"Label_Bace_Title_ADD_ELEMENT")
        self.Label_Bace_Title_ADD_ELEMENT.setGeometry(QRect(150, 20, 401, 71))
        font2 = QFont()
        font2.setPointSize(34)
        self.Label_Bace_Title_ADD_ELEMENT.setFont(font2)
        self.PB_Add_ELEMENT_2 = QPushButton(self.centralwidget)
        self.PB_Add_ELEMENT_2.setObjectName(u"PB_Add_ELEMENT_2")
        self.PB_Add_ELEMENT_2.setGeometry(QRect(270, 640, 191, 61))
        font3 = QFont()
        font3.setPointSize(15)
        self.PB_Add_ELEMENT_2.setFont(font3)
        self.PB_Add_ELEMENT_2.setStyleSheet(u"border: 1px solid gray;\n"
"border-radius: 10px;")
        self.Text_Name = QTextEdit(self.centralwidget)
        self.Text_Name.setObjectName(u"Text_Name")
        self.Text_Name.setGeometry(QRect(260, 190, 331, 31))
        self.Text_Name.setFont(font1)
        self.Text_Name.setAcceptDrops(True)
        self.Text_Name.setStyleSheet(u"border: 1px solid gray;\n"
"border-radius:6px;")
        self.Lable_FIO_3 = QLabel(self.centralwidget)
        self.Lable_FIO_3.setObjectName(u"Lable_FIO_3")
        self.Lable_FIO_3.setGeometry(QRect(110, 500, 59, 23))
        self.Lable_FIO_3.setFont(font)
        self.dateEdit = QDateEdit(self.centralwidget)
        self.dateEdit.setObjectName(u"dateEdit")
        self.dateEdit.setGeometry(QRect(180, 500, 411, 31))
        self.dateEdit.setDateTime(QDateTime(QDate(2000, 1, 1), QTime(0, 0, 0)))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 766, 21))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.Labe_Status.setText(QCoreApplication.translate("MainWindow", u"\u0421\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435:", None))
        self.Box_Status.setItemText(0, QCoreApplication.translate("MainWindow", u"\u0421\u043a\u043b\u0430\u0434", None))
        self.Box_Status.setItemText(1, QCoreApplication.translate("MainWindow", u"\u0410\u0440\u0435\u043d\u0434\u0430", None))
        self.Box_Status.setItemText(2, QCoreApplication.translate("MainWindow", u"\u0421\u043b\u043e\u043c\u043c\u0430\u043d", None))
        self.Box_Status.setItemText(3, QCoreApplication.translate("MainWindow", u"\u0412 \u0440\u0435\u043c\u043e\u043d\u0442\u0435", None))

        self.Labe_Name_.setText(QCoreApplication.translate("MainWindow", u"\u041d\u0430\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u043d\u0438\u0435:", None))
        self.Lable_Note_2.setText(QCoreApplication.translate("MainWindow", u"\u041f\u0440\u0438\u043c\u0435\u0447\u0430\u043d\u0438\u0435:", None))
        self.Box_Project_Name.setItemText(0, QCoreApplication.translate("MainWindow", u"\u041c\u0435\u0442\u0435\u043e\u0441\u0442\u0430\u043d\u0446\u0438\u044f", None))
        self.Box_Project_Name.setItemText(1, QCoreApplication.translate("MainWindow", u"\u0411\u0430\u0437\u0430 \u0414\u0430\u043d\u043d\u044b\u0445", None))
        self.Box_Project_Name.setItemText(2, QCoreApplication.translate("MainWindow", u"\u041c\u0443\u0441\u043e\u0440\u043a\u0430", None))

        self.Box_Name_Subdivade.setItemText(0, QCoreApplication.translate("MainWindow", u"\u0418\u0420\u0422\u0421\u0423", None))

        self.Lable_FIO_2.setText(QCoreApplication.translate("MainWindow", u"\u0424.\u0418.\u041e:", None))
        self.Labe_Count.setText(QCoreApplication.translate("MainWindow", u"\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e:", None))
        self.Labe_Name_Project.setText(QCoreApplication.translate("MainWindow", u"\u041f\u0440\u043e\u0435\u043a\u0442:", None))
        self.Labe_Name_Subdivade.setText(QCoreApplication.translate("MainWindow", u"\u041f\u043e\u0434\u0440\u0430\u0437\u0434\u0435\u043b\u0435\u043d\u0438\u0435:", None))
        self.Box_Type.setItemText(0, QCoreApplication.translate("MainWindow", u"\u041c\u0438\u043a\u0440\u043e\u043f\u0440\u043e\u0446\u0435\u0441\u0441\u043e\u0440", None))
        self.Box_Type.setItemText(1, QCoreApplication.translate("MainWindow", u"\u041f\u043b\u0430\u0442\u0430", None))
        self.Box_Type.setItemText(2, QCoreApplication.translate("MainWindow", u"\u041c\u043e\u0434\u0443\u043b\u044c", None))

        self.Labe_Type.setText(QCoreApplication.translate("MainWindow", u"\u0422\u0438\u043f:", None))
        self.Label_Bace_Title_ADD_ELEMENT.setText(QCoreApplication.translate("MainWindow", u"\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u042d\u043b\u0435\u043c\u0435\u043d\u0442", None))
        self.PB_Add_ELEMENT_2.setText(QCoreApplication.translate("MainWindow", u"\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c", None))
        self.Lable_FIO_3.setText(QCoreApplication.translate("MainWindow", u"\u0414\u0430\u0442\u0430", None))
    # retranslateUi

