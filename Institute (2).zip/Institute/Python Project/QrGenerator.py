import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget,QTableWidget, QMessageBox
from ui_QrCodeGenerator import Ui_MainWindow
from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFileDialog
import sqlite3
import os
import qrcode
import segno

con = sqlite3.connect("DataBace.db")
cur = con.cursor()

class TableModel(QtCore.QAbstractTableModel):
    def __init__(self, data):
        super(TableModel, self).__init__()
        self._data = data

    def data(self, index, role):
        if role == Qt.DisplayRole:
            # See below for the nested-list data structure.
            # .row() indexes into the outer list,
            # .column() indexes into the sub-list
            return self._data[index.row()][index.column()]

    def rowCount(self, index):
        # The length of the outer list.
        return len(self._data)

    def columnCount(self, index):
        # The following takes the first sub-list, and returns
        # the length (only works if all rows are an equal length)
        return len(self._data[0])

class QR_(QMainWindow):
    def __init__(self, parent=None):
        super(QR_, self).__init__(parent)
        self.QR_Code = Ui_MainWindow()
        self.QR_Code.setupUi(self)

        self.CheckDatabase()  # Подтягиваем типы из базы данных
        self.QR_Code.PB_GenerateQR_2.clicked.connect(self.Create_QR_Code)
        self.QR_Code.PB_GenerateQR_4.clicked.connect(self.GetPathWay)





    def CheckDatabase(self):

        cur.execute("SELECT Type_Name FROM Type")
        self.QR_Code.comboBox.addItem('Hello')
        for result in cur:
            self.QR_Code.comboBox.addItems(result)

    def GetPathWay(self): # при нажатии ... выбераем путь куда сохранять QR и устонавливаем выбранный путь в textEdit_2
        file = QFileDialog.getExistingDirectory(self, "Выбрать папку", ".")
        self.QR_Code.textEdit_2.setText(file)

    def Create_QR_Code(self):

        # Фильтрация для выборки элементов

        # Генерация QR PNG с именем id+имя в определённую дирректорию

        way_for_save = self.QR_Code.textEdit_2.toPlainText()
        print(way_for_save)


        if os.path.exists(way_for_save):
            cur.execute("SELECT * FROM Detail")
            for result in cur:
                img_qr = segno.make_qr(result[0])
                img_qr.save(f'{way_for_save}/QR_{str(result[0]) +"_"+ str(result[2])}.png',scale = 5)

                # img_qr.show()
                print(way_for_save)
            #генерируем QR
        else:# Выводим сообщение об ошибке
            MS_NotFound = QMessageBox()
            MS_NotFound.setIcon(QMessageBox.Warning)
            MS_NotFound.setText("Указанный путь не существует !")
            MS_NotFound.setWindowTitle("Error")

            MS_NotFound.exec()














if __name__ == '__main__':
    app = QApplication()
    window = QR_()
    window.show()
    sys.exit(app.exec())

