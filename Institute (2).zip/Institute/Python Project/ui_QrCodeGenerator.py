# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'QrGenerator_2.ui'
##
## Created by: Qt User Interface Compiler version 6.6.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QLabel, QMainWindow,
    QMenuBar, QPushButton, QSizePolicy, QStatusBar,
    QTextEdit, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1092, 704)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.label_2 = QLabel(self.centralwidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(780, 50, 51, 16))
        font = QFont()
        font.setPointSize(14)
        self.label_2.setFont(font)
        self.PB_GenerateQR_2 = QPushButton(self.centralwidget)
        self.PB_GenerateQR_2.setObjectName(u"PB_GenerateQR_2")
        self.PB_GenerateQR_2.setGeometry(QRect(780, 240, 301, 51))
        self.PB_GenerateQR = QPushButton(self.centralwidget)
        self.PB_GenerateQR.setObjectName(u"PB_GenerateQR")
        self.PB_GenerateQR.setGeometry(QRect(780, 80, 301, 51))
        self.comboBox = QComboBox(self.centralwidget)
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setGeometry(QRect(820, 50, 261, 22))
        self.PB_GenerateQR_3 = QPushButton(self.centralwidget)
        self.PB_GenerateQR_3.setObjectName(u"PB_GenerateQR_3")
        self.PB_GenerateQR_3.setGeometry(QRect(780, 140, 301, 51))
        self.label_3 = QLabel(self.centralwidget)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(780, 200, 51, 31))
        self.label_3.setFont(font)
        self.textEdit = QTextEdit(self.centralwidget)
        self.textEdit.setObjectName(u"textEdit")
        self.textEdit.setGeometry(QRect(830, 10, 251, 31))
        self.label_4 = QLabel(self.centralwidget)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(780, 10, 51, 16))
        self.label_4.setFont(font)
        self.textEdit_2 = QTextEdit(self.centralwidget)
        self.textEdit_2.setObjectName(u"textEdit_2")
        self.textEdit_2.setGeometry(QRect(830, 200, 201, 31))
        self.PB_GenerateQR_4 = QPushButton(self.centralwidget)
        self.PB_GenerateQR_4.setObjectName(u"PB_GenerateQR_4")
        self.PB_GenerateQR_4.setGeometry(QRect(1040, 200, 41, 31))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1092, 21))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"QR_Generator", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"\u0422\u0438\u043f:", None))
        self.PB_GenerateQR_2.setText(QCoreApplication.translate("MainWindow", u"\u0421\u043e\u0437\u0434\u0430\u0442\u044c QR", None))
        self.PB_GenerateQR.setText(QCoreApplication.translate("MainWindow", u"\u041f\u043e\u0438\u0441\u043a", None))
        self.PB_GenerateQR_3.setText(QCoreApplication.translate("MainWindow", u"\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"\u041f\u0443\u0442\u044c:", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"\u0418\u043c\u044f:", None))
        self.PB_GenerateQR_4.setText(QCoreApplication.translate("MainWindow", u"...", None))
    # retranslateUi

