import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget,QTableWidget, QMessageBox
from ui_Data_Setup import Ui_MainWindow
from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFileDialog
import sqlite3
import os

con = sqlite3.connect("DataBace.db")
cur = con.cursor()

class FUNCTION():# Выводим сообщение об ошибке
    def MESSAGE(self,Text_Message):

        MS_NotFound = QMessageBox()
        MS_NotFound.setIcon(QMessageBox.Warning)
        MS_NotFound.setText(f"{Text_Message}")
        MS_NotFound.setWindowTitle("Error")
        MS_NotFound.exec()



    # def DELL_ELEMENT(self):
    #     get_name = self.ui.Box_Type.currentText()




class DSS(QMainWindow):
    def __init__(self, parent=None):
        super(DSS, self).__init__(parent)
        self.Data_Setup_Settings = Ui_MainWindow()
        self.Data_Setup_Settings.setupUi(self)
        self.FU = FUNCTION()


        self.CheckDatabase()


        #self.ui_Interface.PB_Info.clicked.connect(self.Data_Setup_Setings)
        self.Data_Setup_Settings.PB_Add_Type.clicked.connect(self.AddType)
        self.Data_Setup_Settings.PB_Add_State.clicked.connect(self.AddState)
        self.Data_Setup_Settings.PB_Add_Project.clicked.connect(self.AddProject)
        self.Data_Setup_Settings.PB_Add_Sabdvide.clicked.connect(self.AddSabdive)

        self.Data_Setup_Settings.PB_Dell_Type.clicked.connect(self.DellType)
        self.Data_Setup_Settings.PB_Dell_State.clicked.connect(self.DellState)
        self.Data_Setup_Settings.PB_Dell_Project.clicked.connect(self.DellProject)
        self.Data_Setup_Settings.PB_Dell_Sabdvide.clicked.connect(self.DellSabdive)





    def CheckDatabase(self):

        self.Data_Setup_Settings.Box_Type.clear()
        self.Data_Setup_Settings.Box_State.clear()
        self.Data_Setup_Settings.Box_Project.clear()
        self.Data_Setup_Settings.Box_Subdive.clear()

        cur.execute("SELECT Type_Name FROM Type")
        for result in cur:
            self.Data_Setup_Settings.Box_Type.addItem(result[0])

        cur.execute("SELECT State_Name FROM State")
        for result in cur:
             self.Data_Setup_Settings.Box_State.addItem(result[0])

        cur.execute("SELECT Project_Name FROM Project")
        for result in cur:
            self.Data_Setup_Settings.Box_Project.addItem(result[0])

        cur.execute("SELECT Subdivision_Name FROM Subdivision")
        for result in cur:
            self.Data_Setup_Settings.Box_Subdive.addItem(result[0])

    def AddType(self):

        text_type = self.Data_Setup_Settings.Text_Type.toPlainText()
        if text_type != '':
            self.Data_Setup_Settings.Box_Type.clear()
            cur.execute(f"""INSERT INTO Type (Type_Name) VALUES('{text_type}')""")
            con.commit()

            cur.execute("SELECT Type_Name FROM Type")
            for result in cur:
                self.Data_Setup_Settings.Box_Type.addItem(result[0])

            self.Data_Setup_Settings.Text_Type.clear()

        else:
            self.FU.MESSAGE('Наименование типа не задано !')

    def AddState(self):

        text_state = self.Data_Setup_Settings.Text_State.toPlainText()
        if text_state != '':
            self.Data_Setup_Settings.Box_State.clear()
            cur.execute(f"""INSERT INTO State (State_Name) VALUES('{text_state}')""")
            con.commit()

            cur.execute("SELECT State_Name FROM State")
            for result in cur:
                self.Data_Setup_Settings.Box_State.addItem(result[0])

            self.Data_Setup_Settings.Text_State.clear()
        else:
            self.FU.MESSAGE('Наименование состояния не задано !')

    def AddSabdive(self):

        text_subdive = self.Data_Setup_Settings.Text_Subdive.toPlainText()
        if text_subdive != '':
            self.Data_Setup_Settings.Box_Subdive.clear()
            cur.execute(f"""INSERT INTO Subdivision (Subdivision_Name) VALUES('{text_subdive}')""")
            con.commit()

            cur.execute("SELECT Subdivision_Name FROM Subdivision")
            for result in cur:
                self.Data_Setup_Settings.Box_Subdive.addItem(result[0])

            self.Data_Setup_Settings.Text_Subdive.clear()

        else:
            self.FU.MESSAGE('Наименование подразделения не задано !')

    def AddProject(self):

        text_project = self.Data_Setup_Settings.Text_Project.toPlainText()

        if text_project != '':
            self.Data_Setup_Settings.Box_Project.clear()
            cur.execute(f"""INSERT INTO Project (Project_Name) VALUES('{text_project}')""")
            con.commit()

            cur.execute("SELECT Project_Name FROM Project")
            for result in cur:
                self.Data_Setup_Settings.Box_Project.addItem(result[0])

            self.Data_Setup_Settings.Text_Project.clear()

        else:
            self.FU.MESSAGE('Наименование проекта не задано !')

    def DellType(self):
        get_name = self.Data_Setup_Settings.Box_Type.currentText()
        index = self.Data_Setup_Settings.Box_Type.findText(f'{get_name}')
        self.Data_Setup_Settings.Box_Type.removeItem(index)
        # DELETE FROM users WHERE user_id = ?
        cur.execute(f"""DELETE FROM Type WHERE Type_Name = '{get_name}'""")
        con.commit()

    def DellState(self):
        get_name_state = self.Data_Setup_Settings.Box_State.currentText()
        index = self.Data_Setup_Settings.Box_State.findText(f'{get_name_state}')
        self.Data_Setup_Settings.Box_State.removeItem(index)
        # DELETE FROM users WHERE user_id = ?
        cur.execute(f"""DELETE FROM State WHERE State_Name = '{get_name_state}'""")
        con.commit()

    def DellProject(self):
        get_name_project = self.Data_Setup_Settings.Box_Project.currentText()
        index = self.Data_Setup_Settings.Box_Project.findText(f'{get_name_project}')
        self.Data_Setup_Settings.Box_Project.removeItem(index)
        # DELETE FROM users WHERE user_id = ?
        cur.execute(f"""DELETE FROM Project WHERE Project_Name = '{get_name_project}'""")
        con.commit()

    def DellSabdive(self):
        get_name_subdive = self.Data_Setup_Settings.Box_Subdive.currentText()
        index = self.Data_Setup_Settings.Box_Subdive.findText(f'{get_name_subdive}')
        self.Data_Setup_Settings.Box_Subdive.removeItem(index)
        # DELETE FROM users WHERE user_id = ?
        cur.execute(f"""DELETE FROM Subdivision WHERE Subdivision_Name = '{get_name_subdive}'""")
        con.commit()











if __name__ == '__main__':
    app = QApplication()
    window = DSS()
    window.show()
    sys.exit(app.exec())
