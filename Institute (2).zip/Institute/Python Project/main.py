import sys
import datetime

import sqlite3

con = sqlite3.connect("DataBace.db")
cur = con.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS Detail (
    ID_Detail   INTEGER PRIMARY KEY,
    Type        TEXT,
    Detail_Name TEXT,
    State       TEXT,
    Note        TEXT,
    ProjectNames TEXT,
    Sabdive     TEXT,
    Person_FIO  TEXT,
    Data        TEXT
    );""")

cur.execute("""CREATE TABLE IF NOT EXISTS Type (
    ID_Type   INTEGER PRIMARY KEY AUTOINCREMENT,
    Type_Name TEXT
);""")

cur.execute("""CREATE TABLE IF NOT EXISTS State (
    ID_State   INTEGER PRIMARY KEY AUTOINCREMENT,
    State_Name TEXT
);
""")

cur.execute("""CREATE TABLE IF NOT EXISTS Project (
    ID_Project   INTEGER PRIMARY KEY AUTOINCREMENT,
    Project_Name TEXT
);
""")

cur.execute("""CREATE TABLE IF NOT EXISTS Subdivision (
    ID_Subdivision   INTEGER PRIMARY KEY AUTOINCREMENT,
    Subdivision_Name TEXT
);
""")


from PySide6.QtWidgets import QApplication, QMainWindow

from ui_mainwindow_new import Ui_MainWindow




class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)

        #self.a = ADD()
        #self.Das = Data()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        #self.a.item()
        self.CheckDatabase()# good

        self.ui.PB_Add_ELEMENT_2.clicked.connect(self.ADD_ELEMENT)

        self.SET_Data()
        #self.ui.Box_Type.addItem('Hello')

    def SET_Data(self): #При запуске окна проверяем текущую дату и вносим и подставим её в поле
        now = datetime.date.today()
        self.ui.dateEdit.setDate(now)


    def CheckDatabase(self):
        self.ui.Box_Type.addItem('Hello')
        #print("hello")
       # a = self.Das.prin()



        cur.execute("SELECT Type_Name FROM Type")

        for result in cur:
            self.ui.Box_Type.addItems(result)

        cur.execute("SELECT State_Name FROM State")

        for result in cur:
            self.ui.Box_Status.addItems(result)

        cur.execute("SELECT Project_Name FROM Project")

        for result in cur:
            self.ui.Box_Project_Name.addItems(result)

        cur.execute("SELECT Subdivision_Name FROM Subdivision")

        for result in cur:
            self.ui.Box_Name_Subdivade.addItems(result)






    def ADD_ELEMENT(self):



        # Считываем значение полей
        text_type_object = self.ui.Box_Type.currentText()
        text_name_object1 = self.ui.Text_Name.toPlainText()
        text_count_object2 = self.ui.Text_Count.toPlainText()
        text_state = self.ui.Box_Status.currentText()
        text_Projectname = self.ui.Box_Project_Name.currentText()
        text_Box_Name_Subdivade = self.ui.Box_Name_Subdivade.currentText()
        text_Note_2_ = self.ui.Text_Note_2.toPlainText()
        text_FIO = self.ui.Text_FIO_2.toPlainText()
        text_Data = self.ui.dateEdit.text()









        self.ui.Box_Type.addItem('Hello')

        if text_count_object2 != '':
            text_count_object2 = int(text_count_object2)

        else:
            text_count_object2 = 0

        if text_count_object2 > 1:
            if text_state == 'Склад':
                for index in range(text_count_object2):
                    # '{text_count_object2}'
                    cur.execute(f"""INSERT INTO Detail (Detail_Name,Note,State,Type,Sabdive,Data)
                                                                         VALUES('{text_name_object1}','{text_Note_2_}','{text_state}','{text_type_object}','{text_Box_Name_Subdivade}','{text_Data}')""")
                    con.commit()
            else:
                for index in range(text_count_object2):
                    # Если не склад тогда ФИО не записываем
                    cur.execute(f"""INSERT INTO Detail (Detail_Name,Note,Person_FIO,State,Type,ProjectNames,Sabdive,Data)
                                                      VALUES('{text_name_object1}','{text_Note_2_}','{text_FIO}','{text_state}','{text_type_object}','{text_Projectname}','{text_Box_Name_Subdivade}','{text_Data}')""")
                    con.commit()




        # self.ui.Text_Note_2.setText(text_type_object + text_state + text_Projectname + text_Box_Name_Subdivade + text_FIO)


if __name__ == '__main__':
    app = QApplication()
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
