# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ui_maininterface_1.ui'
##
## Created by: Qt User Interface Compiler version 6.6.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QMainWindow, QMenuBar,
    QPushButton, QSizePolicy, QStatusBar, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(422, 370)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.label = QLabel(self.centralwidget)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(60, -10, 381, 101))
        font = QFont()
        font.setPointSize(14)
        self.label.setFont(font)
        self.PB_Add_Element = QPushButton(self.centralwidget)
        self.PB_Add_Element.setObjectName(u"PB_Add_Element")
        self.PB_Add_Element.setGeometry(QRect(10, 200, 401, 61))
        self.PB_Info = QPushButton(self.centralwidget)
        self.PB_Info.setObjectName(u"PB_Info")
        self.PB_Info.setGeometry(QRect(10, 80, 401, 61))
        self.PB_Arenda = QPushButton(self.centralwidget)
        self.PB_Arenda.setObjectName(u"PB_Arenda")
        self.PB_Arenda.setGeometry(QRect(10, 140, 401, 61))
        self.PB_QR = QPushButton(self.centralwidget)
        self.PB_QR.setObjectName(u"PB_QR")
        self.PB_QR.setGeometry(QRect(10, 260, 401, 61))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 422, 21))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"\u041f\u0440\u043e\u0435\u043a\u0442\u043d\u0430\u044f \u0434\u0435\u044f\u0442\u0435\u043b\u044c\u043d\u043e\u0441\u0442\u044c \u0418\u0420\u0422\u0421\u0423", None))
        self.PB_Add_Element.setText(QCoreApplication.translate("MainWindow", u"\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u042d\u043b\u0435\u043c\u0435\u043d\u0442", None))
        self.PB_Info.setText(QCoreApplication.translate("MainWindow", u"\u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0411\u0414", None))
        self.PB_Arenda.setText(QCoreApplication.translate("MainWindow", u"\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f", None))
        self.PB_QR.setText(QCoreApplication.translate("MainWindow", u"QR", None))
    # retranslateUi

